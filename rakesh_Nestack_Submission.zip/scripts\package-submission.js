const { execSync } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');

/**
 * Packages the codebase into a clean ZIP file for submission to Nestack.
 * Excludes node_modules, temp files, and test caches.
 */
function packageSubmission() {
  const rootDir = path.resolve(__dirname, '..');
  const zipName = 'rakesh_Nestack_Submission.zip';
  const outputPath = path.join(rootDir, zipName);

  console.log(`Packaging submission from: ${rootDir}`);
  console.log(`Destination: ${outputPath}`);

  if (fs.existsSync(outputPath)) {
    fs.unlinkSync(outputPath);
    console.log(`Removed existing ${zipName}`);
  }

  // Files and directories to package
  const itemsToInclude = [
    'src',
    'public',
    'tests',
    'scripts',
    'server.js',
    'package.json',
    'README.md',
    '.gitignore',
    '.env.example',
    'Dockerfile',
    'render.yaml',
  ];

  const existingItems = itemsToInclude.filter((item) => fs.existsSync(path.join(rootDir, item)));

  // Use cross-platform zip command or PowerShell on Windows
  if (process.platform === 'win32') {
    const fileList = existingItems.map((f) => `'${f}'`).join(', ');
    const psCmd = `powershell -Command "Compress-Archive -Path ${fileList} -DestinationPath '${outputPath}' -Force"`;
    execSync(psCmd, { cwd: rootDir, stdio: 'inherit' });
  } else {
    const fileList = existingItems.join(' ');
    execSync(`zip -r "${outputPath}" ${fileList}`, { cwd: rootDir, stdio: 'inherit' });
  }

  const stats = fs.statSync(outputPath);
  console.log(`\n Successfully generated ${zipName} (${(stats.size / 1024).toFixed(2)} KB)`);
  console.log(`Ready for upload to the Nestack assessment platform.`);
}

packageSubmission();
