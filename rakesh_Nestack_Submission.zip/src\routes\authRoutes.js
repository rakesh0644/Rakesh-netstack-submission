const express = require('express');
const { sendHandler, verifyHandler } = require('../controllers/authController');

const router = express.Router();

/**
 * @route POST /auth/send
 * @desc Generate and send secure OTP to recipient identifier
 * @access Public
 */
router.post('/send', sendHandler);

/**
 * @route POST /auth/verify
 * @desc Verify OTP code and issue session token
 * @access Public
 */
router.post('/verify', verifyHandler);

module.exports = router;
