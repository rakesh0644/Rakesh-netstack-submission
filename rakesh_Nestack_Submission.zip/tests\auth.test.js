const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const app = require('../src/app');
const { otpStore } = require('../src/storage/otpStore');
const { sendRateLimiter } = require('../src/services/rateLimiter');
const { generateSecureOtp } = require('../src/utils/cryptoUtils');

describe('Auth Endpoints Integration Tests', () => {
  let server;
  let baseUrl;
  let capturedOtps = [];
  const originalLog = console.log;

  before(async () => {
    // Intercept console.log to read logged dev OTP during tests
    console.log = (...args) => {
      const msg = args.join(' ');
      const match = msg.match(/OTP Code\s*:\s*(\d{6})/);
      if (match) {
        capturedOtps.push(match[1]);
      }
      // originalLog(...args); // Keep test output clean
    };

    server = http.createServer(app);
    await new Promise((resolve) => server.listen(0, resolve));
    const port = server.address().port;
    baseUrl = `http://127.0.0.1:${port}`;
  });

  after(() => {
    console.log = originalLog;
    server.close();
  });

  beforeEach(() => {
    otpStore.clear();
    sendRateLimiter.reset();
    capturedOtps = [];
  });

  // Helper for HTTP requests
  async function apiRequest(endpoint, body) {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    return { status: res.status, data };
  }

  describe('Criterion 1: CSPRNG & Hashed Storage (30%)', () => {
    test('CSPRNG produces valid 6-digit numeric strings', () => {
      for (let i = 0; i < 50; i++) {
        const otp = generateSecureOtp();
        assert.equal(typeof otp, 'string');
        assert.equal(otp.length, 6);
        assert.match(otp, /^\d{6}$/);
      }
    });

    test('Stored OTP is hashed with bcrypt and never stored in plaintext', async () => {
      const email = 'audit@example.com';
      const res = await apiRequest('/auth/send', { identifier: email });

      assert.equal(res.status, 200);
      assert.equal(res.data.message, `OTP sent to ${email}`);

      // Verify what is stored in the database / store
      const record = otpStore.getLatestOtp(email);
      assert.ok(record, 'Record should exist in store');
      assert.equal(record.identifier, email);
      assert.ok(record.code_hash, 'Hash must exist');

      // Crucial security check: Bcrypt hashes start with $2a$ or $2b$
      assert.match(record.code_hash, /^\$2[ab]\$\d+\$/);

      // Verify that NO plaintext property 'code' exists anywhere in stored object
      assert.equal(record.code, undefined);

      // Audit entire store dump
      const auditRecords = otpStore.auditDump();
      for (const item of auditRecords) {
        assert.equal(item.code, undefined);
        assert.notEqual(item.code_hash, capturedOtps[0]);
      }
    });
  });

  describe('Criterion 2: Send Rate Limiting - Max 3 per 10 min (20%)', () => {
    test('Allows up to 3 send requests and returns 429 on 4th attempt', async () => {
      const email = 'spambot@example.com';

      // 1st request -> 200
      const res1 = await apiRequest('/auth/send', { identifier: email });
      assert.equal(res1.status, 200);

      // 2nd request -> 200
      const res2 = await apiRequest('/auth/send', { identifier: email });
      assert.equal(res2.status, 200);

      // 3rd request -> 200
      const res3 = await apiRequest('/auth/send', { identifier: email });
      assert.equal(res3.status, 200);

      // 4th request -> 429
      const res4 = await apiRequest('/auth/send', { identifier: email });
      assert.equal(res4.status, 429);
      assert.match(res4.data.message, /Rate limit exceeded/i);
      assert.ok(typeof res4.data.retry_after_seconds === 'number');
    });

    test('Normalizes identifier to prevent rate limit bypass via whitespace or casing', async () => {
      const res1 = await apiRequest('/auth/send', { identifier: 'Target@Example.com' });
      assert.equal(res1.status, 200);

      const res2 = await apiRequest('/auth/send', { identifier: 'target@example.com' });
      assert.equal(res2.status, 200);

      const res3 = await apiRequest('/auth/send', { identifier: '  target@example.com  ' });
      assert.equal(res3.status, 200);

      // 4th request with variation -> 429
      const res4 = await apiRequest('/auth/send', { identifier: 'TARGET@EXAMPLE.COM' });
      assert.equal(res4.status, 429);
    });
  });

  describe('Criterion 3: Brute-Force Protection - Lockout after 5 failed attempts (25%)', () => {
    test('Locks OTP after 5 incorrect attempts and returns 429', async () => {
      const email = 'victim@example.com';
      await apiRequest('/auth/send', { identifier: email });

      // Failed attempt 1 -> 400, 4 remaining
      const try1 = await apiRequest('/auth/verify', { identifier: email, code: '000001' });
      assert.equal(try1.status, 400);
      assert.equal(try1.data.attempts_remaining, 4);

      // Failed attempt 2 -> 400, 3 remaining
      const try2 = await apiRequest('/auth/verify', { identifier: email, code: '000002' });
      assert.equal(try2.status, 400);
      assert.equal(try2.data.attempts_remaining, 3);

      // Failed attempt 3 -> 400, 2 remaining
      const try3 = await apiRequest('/auth/verify', { identifier: email, code: '000003' });
      assert.equal(try3.status, 400);
      assert.equal(try3.data.attempts_remaining, 2);

      // Failed attempt 4 -> 400, 1 remaining
      const try4 = await apiRequest('/auth/verify', { identifier: email, code: '000004' });
      assert.equal(try4.status, 400);
      assert.equal(try4.data.attempts_remaining, 1);

      // Failed attempt 5 -> 429 (Locked!)
      const try5 = await apiRequest('/auth/verify', { identifier: email, code: '000005' });
      assert.equal(try5.status, 429);
      assert.equal(try5.data.attempts_remaining, 0);
      assert.match(try5.data.message, /Too many failed attempts/i);

      // Even if attacker tries the correct code after lock, it must reject with 429
      const correctCode = capturedOtps[capturedOtps.length - 1];
      const try6 = await apiRequest('/auth/verify', { identifier: email, code: correctCode });
      assert.equal(try6.status, 429);
      assert.match(try6.data.message, /Too many failed attempts/i);
    });
  });

  describe('Criterion 4: Code Invalidation - Used and Expired Codes (15%)', () => {
    test('Successful verification returns session_token and immediately marks code as used', async () => {
      const email = 'alice@example.com';
      await apiRequest('/auth/send', { identifier: email });
      const sentCode = capturedOtps[capturedOtps.length - 1];

      // Successful verify
      const verifyRes = await apiRequest('/auth/verify', { identifier: email, code: sentCode });
      assert.equal(verifyRes.status, 200);
      assert.equal(verifyRes.data.message, 'Verified');
      assert.ok(typeof verifyRes.data.session_token === 'string');
      assert.equal(verifyRes.data.session_token.length, 64); // 32 bytes hex

      // Immediate reuse attempt with the same valid code must fail with 400
      const replayRes = await apiRequest('/auth/verify', { identifier: email, code: sentCode });
      assert.equal(replayRes.status, 400);
      assert.match(replayRes.data.message, /Invalid or expired code/i);
    });

    test('Rejects verification attempt if code is expired', async () => {
      const email = 'bob@example.com';
      await apiRequest('/auth/send', { identifier: email });
      const sentCode = capturedOtps[capturedOtps.length - 1];

      // Manually set record expires_at to 1 second in the past to simulate 10 min timeout
      const record = otpStore.records.get(email);
      record.expires_at = Date.now() - 1000;
      otpStore.records.set(email, record);

      const expiredRes = await apiRequest('/auth/verify', { identifier: email, code: sentCode });
      assert.equal(expiredRes.status, 400);
      assert.match(expiredRes.data.message, /Invalid or expired code/i);
    });
  });

  describe('Input Validation & Edge Cases', () => {
    test('Rejects missing or invalid identifier on /send', async () => {
      const res1 = await apiRequest('/auth/send', {});
      assert.equal(res1.status, 400);

      const res2 = await apiRequest('/auth/send', { identifier: 'not-an-email-or-phone' });
      assert.equal(res2.status, 400);
    });

    test('Rejects malformed OTP formats on /verify', async () => {
      const email = 'valid@example.com';
      await apiRequest('/auth/send', { identifier: email });

      const res1 = await apiRequest('/auth/verify', { identifier: email, code: 'abc' });
      assert.equal(res1.status, 400);

      const res2 = await apiRequest('/auth/verify', { identifier: email, code: '12345' }); // 5 digits
      assert.equal(res2.status, 400);

      const res3 = await apiRequest('/auth/verify', { identifier: email, code: '1234567' }); // 7 digits
      assert.equal(res3.status, 400);
    });
  });
});
