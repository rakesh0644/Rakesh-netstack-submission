/**
 * In-Memory OTP Storage Layer
 *
 * Persists OTP metadata and hashed secrets per identifier.
 * Plaintext codes are strictly forbidden from entering storage.
 */

class OtpStore {
  constructor() {
    /**
     * Map of identifier -> OtpRecord
     * @type {Map<string, {
     *   identifier: string,
     *   code_hash: string,
     *   created_at: number,
     *   expires_at: number,
     *   used: boolean,
     *   attempts: number
     * }>}
     */
    this.records = new Map();
  }

  /**
   * Saves a new OTP record for an identifier.
   * Replaces any existing active OTP for the same identifier.
   *
   * @param {Object} params
   * @param {string} params.identifier
   * @param {string} params.code_hash
   * @param {number} params.created_at
   * @param {number} params.expires_at
   * @returns {Object} Stored record (shallow copy)
   */
  saveOtp({ identifier, code_hash, created_at, expires_at }) {
    if (!identifier || !code_hash) {
      throw new Error('identifier and code_hash are strictly required');
    }

    const record = {
      identifier,
      code_hash,
      created_at: created_at || Date.now(),
      expires_at,
      used: false,
      attempts: 0,
    };

    this.records.set(identifier, record);
    return { ...record };
  }

  /**
   * Retrieves the current OTP record for an identifier.
   *
   * @param {string} identifier
   * @returns {Object|null}
   */
  getLatestOtp(identifier) {
    const record = this.records.get(identifier);
    if (!record) {
      return null;
    }
    return { ...record };
  }

  /**
   * Increments the attempt counter for an identifier's current OTP.
   *
   * @param {string} identifier
   * @returns {number} The updated attempt count
   */
  incrementAttempts(identifier) {
    const record = this.records.get(identifier);
    if (!record) {
      return 0;
    }
    record.attempts += 1;
    this.records.set(identifier, record);
    return record.attempts;
  }

  /**
   * Marks an OTP as used immediately upon successful verification.
   *
   * @param {string} identifier
   * @returns {boolean}
   */
  markAsUsed(identifier) {
    const record = this.records.get(identifier);
    if (!record) {
      return false;
    }
    record.used = true;
    this.records.set(identifier, record);
    return true;
  }

  /**
   * Removes record for testing or cleanup.
   *
   * @param {string} [identifier]
   */
  clear(identifier) {
    if (identifier) {
      this.records.delete(identifier);
    } else {
      this.records.clear();
    }
  }

  /**
   * Returns a snapshot of all stored records for audit/testing.
   * Used by test suites to verify that plaintext codes are never stored.
   *
   * @returns {Array<Object>}
   */
  auditDump() {
    return Array.from(this.records.values()).map((r) => ({ ...r }));
  }

  /**
   * Periodic garbage collection to remove expired and used records older than 1 hour.
   * Prevents memory leaks in production.
   */
  purgeExpired() {
    const now = Date.now();
    for (const [key, record] of this.records.entries()) {
      if (now > record.expires_at + 3600000) {
        this.records.delete(key);
      }
    }
  }
}

// Export singleton instance
const otpStore = new OtpStore();
module.exports = {
  OtpStore,
  otpStore,
};
