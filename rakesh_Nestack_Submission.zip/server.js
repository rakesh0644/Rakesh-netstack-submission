const app = require('./src/app');
const config = require('./src/config');

const server = app.listen(config.port, () => {
  console.log(`=======================================================`);
  console.log(`🛡️  Abuse-Resistant OTP Backend running on port ${config.port}`);
  console.log(`📡 Endpoints:`);
  console.log(`   - POST http://localhost:${config.port}/auth/send`);
  console.log(`   - POST http://localhost:${config.port}/auth/verify`);
  console.log(`   - GET  http://localhost:${config.port}/health`);
  console.log(`   - GET  http://localhost:${config.port}/ (Interactive Test Dashboard)`);
  console.log(`⚙️  Environment: ${config.nodeEnv}`);
  console.log(`=======================================================`);
});

// Graceful shutdown handling
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
  });
});

module.exports = server;
