const config = require('../config');
const { generateSecureOtp, generateSessionToken, hashOtp, verifyOtpHash } = require('../utils/cryptoUtils');
const { normalizeIdentifier, isValidIdentifier, isValidOtpFormat } = require('../utils/validator');
const { otpStore } = require('../storage/otpStore');
const { sendRateLimiter } = require('./rateLimiter');

/**
 * Custom application errors with corresponding HTTP status codes
 */
class AuthError extends Error {
  constructor(message, statusCode, extra = {}) {
    super(message);
    this.name = 'AuthError';
    this.statusCode = statusCode;
    this.extra = extra;
  }
}

class OtpService {
  /**
   * Generates, hashes, and records a new OTP for an identifier.
   * Enforces send rate limits (max 3 sends per 10 minutes).
   *
   * @param {string} rawIdentifier - Email or phone number
   * @returns {Promise<{ identifier: string, message: string }>}
   */
  async sendOtp(rawIdentifier) {
    const identifier = normalizeIdentifier(rawIdentifier);

    if (!identifier || !isValidIdentifier(identifier)) {
      throw new AuthError('A valid email or phone number is required', 400);
    }

    // 1. Enforce Send Rate Limit (Max 3 per 10-minute window)
    const limitStatus = sendRateLimiter.checkLimit(identifier);
    if (!limitStatus.allowed) {
      throw new AuthError(
        'Rate limit exceeded. Maximum 3 OTP requests allowed per 10-minute window.',
        429,
        { retry_after_seconds: limitStatus.retryAfterSeconds }
      );
    }

    // 2. Generate cryptographically random 6-digit OTP
    const rawOtp = generateSecureOtp();

    // 3. Hash code using bcrypt (never stored in plaintext)
    const codeHash = await hashOtp(rawOtp);

    // 4. Record the rate limit hit
    sendRateLimiter.consume(identifier);

    // 5. Store record in storage with required metadata
    const now = Date.now();
    otpStore.saveOtp({
      identifier,
      code_hash: codeHash,
      created_at: now,
      expires_at: now + config.otp.ttlMs,
    });

    // 6. Simulate SMS/Email dispatch in development by logging to console
    // In production, this would dispatch through Twilio/SendGrid.
    console.log(`\n========================================`);
    console.log(`[DISPATCH SIMULATOR] Outbound OTP Delivery`);
    console.log(`Recipient  : ${identifier}`);
    console.log(`OTP Code   : ${rawOtp}`);
    console.log(`Expires At : ${new Date(now + config.otp.ttlMs).toISOString()}`);
    console.log(`========================================\n`);

    return {
      identifier,
      message: `OTP sent to ${identifier}`,
    };
  }

  /**
   * Verifies an OTP code for an identifier and issues a session token.
   * Enforces brute-force lockout, expiration, and single-use invalidation.
   *
   * @param {string} rawIdentifier
   * @param {string} rawCode
   * @returns {Promise<{ message: string, session_token: string }>}
   */
  async verifyOtp(rawIdentifier, rawCode) {
    const identifier = normalizeIdentifier(rawIdentifier);

    if (!identifier || !isValidIdentifier(identifier)) {
      throw new AuthError('A valid email or phone number is required', 400);
    }

    if (!rawCode || typeof rawCode !== 'string') {
      throw new AuthError('A 6-digit OTP code is required', 400);
    }

    const code = rawCode.trim();
    if (!isValidOtpFormat(code)) {
      throw new AuthError('Invalid code format. OTP must be 6 digits.', 400);
    }

    // 1. Fetch active OTP record
    const record = otpStore.getLatestOtp(identifier);

    if (!record) {
      throw new AuthError('Invalid or expired code', 400);
    }

    // 2. Check if the OTP is already locked due to exceeding 5 attempts
    if (record.attempts >= config.otp.maxVerifyAttempts) {
      throw new AuthError('Too many failed attempts. OTP has been locked.', 429, {
        attempts_remaining: 0,
      });
    }

    // 3. Check for code expiration (10-minute window)
    const now = Date.now();
    if (now > record.expires_at) {
      throw new AuthError('Invalid or expired code', 400);
    }

    // 4. Check for code reuse (single-use enforcement)
    if (record.used) {
      throw new AuthError('Invalid or expired code', 400);
    }

    // 5. Compare submitted code with stored bcrypt hash
    const isMatch = await verifyOtpHash(code, record.code_hash);

    if (!isMatch) {
      // Increment attempt counter
      const updatedAttempts = otpStore.incrementAttempts(identifier);

      // Check if this failed attempt reached the 5-attempt brute-force limit
      if (updatedAttempts >= config.otp.maxVerifyAttempts) {
        throw new AuthError('Too many failed attempts. OTP has been locked.', 429, {
          attempts_remaining: 0,
        });
      }

      const attemptsRemaining = config.otp.maxVerifyAttempts - updatedAttempts;
      throw new AuthError('Invalid or expired code', 400, {
        attempts_remaining: attemptsRemaining,
      });
    }

    // 6. Verification Succeeded:
    // Invalidate immediately to prevent reuse
    otpStore.markAsUsed(identifier);

    // Issue opaque session token
    const sessionToken = generateSessionToken();

    return {
      message: 'Verified',
      session_token: sessionToken,
    };
  }
}

const otpService = new OtpService();

module.exports = {
  OtpService,
  otpService,
  AuthError,
};
