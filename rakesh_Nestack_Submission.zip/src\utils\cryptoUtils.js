const crypto = require('node:crypto');
const bcrypt = require('bcryptjs');
const config = require('../config');

/**
 * Cryptographic Utility Functions
 *
 * Implements CSPRNG generation and secure one-way hashing
 * as mandated by the security specification.
 */

/**
 * Generates a cryptographically secure 6-digit numeric OTP.
 *
 * Uses Node's native `crypto.randomInt(min, max)` which wraps the OS CSPRNG
 * (CryptGenRandom/BCryptGenRandom on Windows, /dev/urandom or getrandom(2) on Linux/macOS).
 * Guarantees uniform distribution without modulo bias across all 1,000,000 combinations (000000 - 999999).
 *
 * @returns {string} 6-digit numeric string
 */
function generateSecureOtp() {
  const max = Math.pow(10, config.otp.length); // 1,000,000
  const randomValue = crypto.randomInt(0, max);
  return randomValue.toString().padStart(config.otp.length, '0');
}

/**
 * Generates an opaque, cryptographically random session token.
 *
 * Uses `crypto.randomBytes` with 256 bits of entropy.
 *
 * @returns {string} 64-character hexadecimal token
 */
function generateSessionToken() {
  return crypto.randomBytes(config.security.sessionTokenBytes).toString('hex');
}

/**
 * Hashes an OTP code using bcrypt with configurable work factor.
 *
 * Why bcrypt instead of SHA-256 for 6-digit OTPs:
 * A 6-digit code has only 1,000,000 permutations (~20 bits entropy).
 * SHA-256 can be brute-forced across the entire keyspace in under 1 millisecond on modern GPUs.
 * Bcrypt forces iterative CPU/memory cost (~80ms per comparison), rendering offline brute force
 * computationally infeasible within the 10-minute expiry window.
 *
 * @param {string} code - The 6-digit OTP string
 * @returns {Promise<string>} The bcrypt hash string
 */
async function hashOtp(code) {
  if (typeof code !== 'string') {
    throw new TypeError('OTP code must be a string');
  }
  return bcrypt.hash(code, config.security.bcryptSaltRounds);
}

/**
 * Verifies a plaintext OTP code against a stored bcrypt hash.
 *
 * @param {string} code - Submitted candidate code
 * @param {string} hash - Stored hash
 * @returns {Promise<boolean>}
 */
async function verifyOtpHash(code, hash) {
  if (!code || !hash) {
    return false;
  }
  return bcrypt.compare(code, hash);
}

/**
 * Performs constant-time comparison of two string buffers.
 * Prevents timing side-channel attacks when comparing opaque tokens.
 *
 * @param {string} a
 * @param {string} b
 * @returns {boolean}
 */
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') {
    return false;
  }
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) {
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}

module.exports = {
  generateSecureOtp,
  generateSessionToken,
  hashOtp,
  verifyOtpHash,
  safeEqual,
};
