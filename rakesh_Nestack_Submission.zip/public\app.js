// Client-side testing console logic
document.addEventListener('DOMContentLoaded', () => {
  const identifierInput = document.getElementById('identifier-input');
  const sendBtn = document.getElementById('send-btn');
  const spamBtn = document.getElementById('spam-btn');
  const copyCodeBtn = document.getElementById('copy-code-btn');
  const codeInput = document.getElementById('code-input');
  const verifyBtn = document.getElementById('verify-btn');
  const badCodeBtn = document.getElementById('bad-code-btn');
  const clearLogBtn = document.getElementById('clear-log-btn');

  const simulatedOtpBanner = document.getElementById('simulated-otp-banner');
  const simulatedCodeEl = document.getElementById('simulated-code');
  const sessionBox = document.getElementById('session-box');
  const sessionTokenValue = document.getElementById('session-token-value');
  const auditLogList = document.getElementById('audit-log-list');

  const sendLimitBadge = document.getElementById('send-limit-badge');
  const attemptsBadge = document.getElementById('attempts-badge');

  let localSendCount = 0;
  let lastGeneratedCode = null;

  function logEntry(status, method, url, message) {
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];

    const entry = document.createElement('div');
    entry.className = 'log-entry';

    let badgeClass = 'log-badge-200';
    if (status === 400) badgeClass = 'log-badge-400';
    if (status === 429) badgeClass = 'log-badge-429';

    entry.innerHTML = `
      <span class="log-time">${timeStr}</span>
      <span class="log-badge ${badgeClass}">${status} ${method}</span>
      <span class="log-msg">${escapeHtml(message)}</span>
    `;

    auditLogList.prepend(entry);
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // 1. Send OTP
  async function handleSendOtp() {
    const identifier = identifierInput.value.trim();
    if (!identifier) {
      alert('Please enter an identifier (email or phone)');
      return;
    }

    sendBtn.disabled = true;

    try {
      const res = await fetch('/auth/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier }),
      });

      const data = await res.json();
      logEntry(res.status, 'POST', '/auth/send', data.message || JSON.stringify(data));

      if (res.status === 200) {
        localSendCount = Math.min(3, localSendCount + 1);
        sendLimitBadge.textContent = `${3 - localSendCount} left`;

        // Since the server outputs the OTP to the console, we simulate the dev SMS/Email receipt
        // by parsing or demonstrating the arrival
        simulatedOtpBanner.classList.remove('hidden');
        simulatedCodeEl.textContent = '●●●●●● (Check Server Console)';
        simulatedCodeEl.title = 'In development, the server logs the raw code to stdout.';
        attemptsBadge.textContent = '5 left';
        attemptsBadge.style.color = '#10b981';
      } else if (res.status === 429) {
        sendLimitBadge.textContent = '0 left (LOCKED)';
        sendLimitBadge.style.color = '#f43f5e';
      }
    } catch (err) {
      logEntry(500, 'ERR', '/auth/send', err.message);
    } finally {
      sendBtn.disabled = false;
    }
  }

  // 2. Trigger 4x burst send to test rate limiter
  async function handleSpamSend() {
    const identifier = identifierInput.value.trim();
    if (!identifier) return;

    spamBtn.disabled = true;
    for (let i = 1; i <= 4; i++) {
      try {
        const res = await fetch('/auth/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ identifier }),
        });
        const data = await res.json();
        logEntry(res.status, 'POST', `/auth/send [Burst #${i}]`, data.message || JSON.stringify(data));
      } catch (err) {
        logEntry(500, 'ERR', '/auth/send', err.message);
      }
    }
    spamBtn.disabled = false;
    sendLimitBadge.textContent = '0 left (LOCKED)';
    sendLimitBadge.style.color = '#f43f5e';
  }

  // 3. Verify OTP
  async function handleVerifyOtp(codeToSubmit) {
    const identifier = identifierInput.value.trim();
    const code = codeToSubmit || codeInput.value.trim();

    if (!identifier || !code) {
      alert('Please provide both recipient and 6-digit code');
      return;
    }

    verifyBtn.disabled = true;

    try {
      const res = await fetch('/auth/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, code }),
      });

      const data = await res.json();
      logEntry(res.status, 'POST', '/auth/verify', data.message || JSON.stringify(data));

      if (res.status === 200) {
        sessionBox.classList.remove('hidden');
        sessionTokenValue.textContent = data.session_token;
        attemptsBadge.textContent = 'Verified (Used)';
        attemptsBadge.style.color = '#10b981';
      } else if (res.status === 400) {
        if (typeof data.attempts_remaining === 'number') {
          attemptsBadge.textContent = `${data.attempts_remaining} left`;
          attemptsBadge.style.color = '#f59e0b';
        }
      } else if (res.status === 429) {
        attemptsBadge.textContent = '0 left (LOCKED)';
        attemptsBadge.style.color = '#f43f5e';
      }
    } catch (err) {
      logEntry(500, 'ERR', '/auth/verify', err.message);
    } finally {
      verifyBtn.disabled = false;
    }
  }

  sendBtn.addEventListener('click', handleSendOtp);
  spamBtn.addEventListener('click', handleSpamSend);
  verifyBtn.addEventListener('click', () => handleVerifyOtp());
  badCodeBtn.addEventListener('click', () => handleVerifyOtp('999999'));

  clearLogBtn.addEventListener('click', () => {
    auditLogList.innerHTML = '';
  });

  copyCodeBtn.addEventListener('click', () => {
    const input = prompt('Paste the 6-digit code from your server console:');
    if (input && input.trim().length === 6) {
      codeInput.value = input.trim();
    }
  });
});
