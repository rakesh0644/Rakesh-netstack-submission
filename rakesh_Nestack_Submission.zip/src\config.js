/**
 * Application Configuration & Security Constants
 */
const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',

  otp: {
    // 6-digit numeric OTP length
    length: 6,
    // Validity duration: 10 minutes in milliseconds
    ttlMs: 10 * 60 * 1000,
    // Maximum allowed incorrect attempts before the OTP is permanently locked
    maxVerifyAttempts: 5,
  },

  rateLimit: {
    // Maximum send requests allowed per identifier within the window
    sendMaxRequests: 3,
    // Send rate limit time window: 10 minutes in milliseconds
    sendWindowMs: 10 * 60 * 1000,
  },

  security: {
    // Bcrypt cost factor (10 provides strong resistance against offline brute force)
    bcryptSaltRounds: 10,
    // Opaque session token byte length (32 bytes = 256 bits of CSPRNG entropy)
    sessionTokenBytes: 32,
  },
};

module.exports = config;
