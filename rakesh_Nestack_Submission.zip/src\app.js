const express = require('express');
const path = require('node:path');
const authRoutes = require('./routes/authRoutes');

const app = express();

// Disable x-powered-by header for security
app.disable('x-powered-by');

// Parse JSON request bodies with reasonable limit
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true }));

// Enable CORS for frontend clients / testing
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

// Serve interactive testing dashboard from public/
app.use(express.static(path.join(__dirname, '..', 'public')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    service: 'Abuse-Resistant OTP System',
    timestamp: new Date().toISOString(),
  });
});

// Mount authentication routes under /auth
app.use('/auth', authRoutes);

// 404 handler for unknown routes
app.use((req, res) => {
  res.status(404).json({
    message: `Route not found: ${req.method} ${req.originalUrl}`,
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('[Unhandled Server Error]:', err);
  res.status(500).json({
    message: 'Internal server error',
  });
});

module.exports = app;
