const config = require('../config');

/**
 * Sliding Window Rate Limiter
 *
 * Implements a strict sliding-window log per identifier to enforce the send rate limit:
 * Max 3 requests per identifier per 10-minute window.
 *
 * Why sliding window instead of fixed window:
 * Fixed windows allow burst attacks at window boundaries (e.g. 3 at 9:59 and 3 at 10:00).
 * Sliding window enforces a strict maximum across any rolling 10-minute duration.
 */
class SlidingWindowRateLimiter {
  constructor(maxRequests = config.rateLimit.sendMaxRequests, windowMs = config.rateLimit.sendWindowMs) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
    /**
     * Map of identifier -> array of unix epoch millisecond timestamps
     * @type {Map<string, number[]>}
     */
    this.history = new Map();
  }

  /**
   * Cleans up timestamps outside the sliding window for an identifier.
   *
   * @param {string} identifier
   * @param {number} now
   * @returns {number[]} Active timestamps within the sliding window
   */
  _getActiveTimestamps(identifier, now) {
    const timestamps = this.history.get(identifier);
    if (!timestamps || timestamps.length === 0) {
      return [];
    }

    const cutoff = now - this.windowMs;
    const active = timestamps.filter((ts) => ts > cutoff);

    if (active.length === 0) {
      this.history.delete(identifier);
    } else {
      this.history.set(identifier, active);
    }

    return active;
  }

  /**
   * Checks whether a new request is allowed under the rate limit.
   *
   * @param {string} identifier
   * @param {number} [now=Date.now()]
   * @returns {{
   *   allowed: boolean,
   *   currentCount: number,
   *   maxRequests: number,
   *   remaining: number,
   *   retryAfterSeconds: number
   * }}
   */
  checkLimit(identifier, now = Date.now()) {
    const active = this._getActiveTimestamps(identifier, now);
    const count = active.length;

    if (count >= this.maxRequests) {
      const oldestTimestamp = active[0];
      const resetTime = oldestTimestamp + this.windowMs;
      const retryAfterMs = Math.max(0, resetTime - now);
      const retryAfterSeconds = Math.ceil(retryAfterMs / 1000);

      return {
        allowed: false,
        currentCount: count,
        maxRequests: this.maxRequests,
        remaining: 0,
        retryAfterSeconds,
      };
    }

    return {
      allowed: true,
      currentCount: count,
      maxRequests: this.maxRequests,
      remaining: this.maxRequests - count,
      retryAfterSeconds: 0,
    };
  }

  /**
   * Records a request hit for an identifier if allowed.
   *
   * @param {string} identifier
   * @param {number} [now=Date.now()]
   * @returns {boolean} True if recorded, false if rate limited
   */
  consume(identifier, now = Date.now()) {
    const status = this.checkLimit(identifier, now);
    if (!status.allowed) {
      return false;
    }

    const active = this._getActiveTimestamps(identifier, now);
    active.push(now);
    this.history.set(identifier, active);
    return true;
  }

  /**
   * Resets rate limit history for a specific identifier or all.
   *
   * @param {string} [identifier]
   */
  reset(identifier) {
    if (identifier) {
      this.history.delete(identifier);
    } else {
      this.history.clear();
    }
  }
}

// Export singleton instance
const sendRateLimiter = new SlidingWindowRateLimiter();

module.exports = {
  SlidingWindowRateLimiter,
  sendRateLimiter,
};
