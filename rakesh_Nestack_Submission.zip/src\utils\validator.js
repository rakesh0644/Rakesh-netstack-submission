/**
 * Input Validation and Identifier Normalization Utilities
 */

/**
 * Normalizes an identifier (email or phone) to ensure consistent rate limiting and lookup.
 * - Trims surrounding whitespace
 * - Converts emails to lowercase
 * - Strips formatting whitespace/hyphens/parentheses from phone numbers
 *
 * @param {string} rawIdentifier
 * @returns {string} Normalized identifier
 */
function normalizeIdentifier(rawIdentifier) {
  if (typeof rawIdentifier !== 'string') {
    return '';
  }

  const trimmed = rawIdentifier.trim();
  if (trimmed.includes('@')) {
    return trimmed.toLowerCase();
  }

  // If looks like phone number, preserve leading '+' but remove formatting characters
  return trimmed.replace(/[\s\(\)\-]/g, '');
}

/**
 * Basic format validation for email or phone identifiers.
 *
 * @param {string} identifier
 * @returns {boolean}
 */
function isValidIdentifier(identifier) {
  if (!identifier || typeof identifier !== 'string') {
    return false;
  }

  const cleaned = identifier.trim();
  if (cleaned.length < 3 || cleaned.length > 254) {
    return false;
  }

  // Check if email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (emailRegex.test(cleaned)) {
    return true;
  }

  // Check if international phone format (+1234567890 or digits)
  const phoneRegex = /^\+?[1-9]\d{6,14}$/;
  if (phoneRegex.test(cleaned.replace(/[\s\(\)\-]/g, ''))) {
    return true;
  }

  return false;
}

/**
 * Validates that an OTP code is exactly 6 digits.
 *
 * @param {string} code
 * @returns {boolean}
 */
function isValidOtpFormat(code) {
  if (typeof code !== 'string') {
    return false;
  }
  return /^\d{6}$/.test(code.trim());
}

module.exports = {
  normalizeIdentifier,
  isValidIdentifier,
  isValidOtpFormat,
};
