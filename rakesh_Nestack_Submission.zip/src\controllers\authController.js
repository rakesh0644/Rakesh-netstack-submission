const { otpService, AuthError } = require('../services/otpService');

/**
 * Controller handling authentication endpoints
 */

/**
 * Handles POST /auth/send
 * Body: { "identifier": string }
 */
async function sendHandler(req, res, next) {
  try {
    const { identifier } = req.body || {};

    if (!identifier) {
      return res.status(400).json({
        message: 'Identifier (email or phone) is required in request body',
      });
    }

    const result = await otpService.sendOtp(identifier);
    return res.status(200).json({
      message: result.message,
    });
  } catch (error) {
    if (error instanceof AuthError) {
      return res.status(error.statusCode).json({
        message: error.message,
        ...error.extra,
      });
    }
    return next(error);
  }
}

/**
 * Handles POST /auth/verify
 * Body: { "identifier": string, "code": string }
 */
async function verifyHandler(req, res, next) {
  try {
    const { identifier, code } = req.body || {};

    if (!identifier || code === undefined || code === null) {
      return res.status(400).json({
        message: 'Both identifier and code are required in request body',
      });
    }

    const result = await otpService.verifyOtp(identifier, String(code));
    return res.status(200).json({
      message: result.message,
      session_token: result.session_token,
    });
  } catch (error) {
    if (error instanceof AuthError) {
      return res.status(error.statusCode).json({
        message: error.message,
        ...error.extra,
      });
    }
    return next(error);
  }
}

module.exports = {
  sendHandler,
  verifyHandler,
};
