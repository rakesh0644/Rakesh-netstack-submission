const { test, describe, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { SlidingWindowRateLimiter } = require('../src/services/rateLimiter');

describe('SlidingWindowRateLimiter Unit Tests', () => {
  let limiter;
  const WINDOW_MS = 10 * 60 * 1000; // 10 minutes
  const MAX_REQUESTS = 3;

  beforeEach(() => {
    limiter = new SlidingWindowRateLimiter(MAX_REQUESTS, WINDOW_MS);
  });

  test('allows requests within limit of 3 per window', () => {
    const id = 'user@example.com';
    const t0 = 1000000;

    assert.equal(limiter.consume(id, t0), true);
    assert.equal(limiter.consume(id, t0 + 1000), true);
    assert.equal(limiter.consume(id, t0 + 2000), true);

    // 4th request at t0 + 3000 should be rejected
    assert.equal(limiter.consume(id, t0 + 3000), false);

    const check = limiter.checkLimit(id, t0 + 3000);
    assert.equal(check.allowed, false);
    assert.equal(check.currentCount, 3);
    assert.equal(check.remaining, 0);
  });

  test('correctly calculates retry-after when limit is breached', () => {
    const id = 'user@example.com';
    const t0 = 1000000;

    limiter.consume(id, t0);
    limiter.consume(id, t0 + 10000);
    limiter.consume(id, t0 + 20000);

    const check = limiter.checkLimit(id, t0 + 30000);
    assert.equal(check.allowed, false);
    // Oldest was at t0, window is 600,000ms. Reset is at t0 + 600,000ms.
    // At t0 + 30,000ms, retryAfterMs = 570,000ms -> 570 seconds.
    assert.equal(check.retryAfterSeconds, 570);
  });

  test('resets after window expires', () => {
    const id = 'user@example.com';
    const t0 = 1000000;

    limiter.consume(id, t0);
    limiter.consume(id, t0 + 1000);
    limiter.consume(id, t0 + 2000);

    // At t0 + 10 minutes + 1 ms, the first request expired
    const afterWindow = t0 + WINDOW_MS + 1;
    const check = limiter.checkLimit(id, afterWindow);
    assert.equal(check.allowed, true);
    assert.equal(check.currentCount, 2); // 2 remaining in window
    assert.equal(check.remaining, 1);
  });

  test('tracks identifiers independently', () => {
    const userA = 'alice@example.com';
    const userB = 'bob@example.com';
    const t0 = 1000000;

    limiter.consume(userA, t0);
    limiter.consume(userA, t0);
    limiter.consume(userA, t0);

    // userA is blocked
    assert.equal(limiter.consume(userA, t0), false);

    // userB is not affected
    assert.equal(limiter.consume(userB, t0), true);
    assert.equal(limiter.checkLimit(userB, t0).remaining, 2);
  });
});
